package screens;

import com.badlogic.gdx.Screen;

import controllers.GameplayController;

/**
 * Created by C on 1/7/2017.
 */

public class Gameplay implements Screen {

    public Gameplay(GameplayController controller){

    }
    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
