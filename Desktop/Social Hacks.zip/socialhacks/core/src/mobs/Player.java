package mobs;

import com.badlogic.gdx.graphics.g2d.Sprite;

/**
 * Created by C on 1/7/2017.
 */

public class Player {
    private Sprite sprite;

    public Player(){}
}
